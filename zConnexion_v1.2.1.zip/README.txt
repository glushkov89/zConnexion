zConnexion adds 3DConnexion`s devices support to zBrush.

Versions:

v1.0 - will work on zB2018 or lower.

v1.1.1 - zB2019, 2020, 2020.1.1. Added a bit of optimization (worls better with higher poly models)

v1.2 - added support for 3DConnexion specific commands (like QuickZoomIn, change to top view, save view etc.).    

v1.2.1 - corrected behaviour 3DConnexion specific commands (like QuickZoomIn, change to top view, save view etc.).

Installation:
1. 3DConnexion driver needs to be installed in the system. Delete all previous zConnexion files from [zBrush folder]\ZStartup\ZPlugs64.
2. Copy "zConnexion.zsc", "zConnexion.dll", "zConnexion.exe" and zC_Data folder to [zBrush folder]\ZStartup\ZPlugs64.
3. Make shortcut of "zConnexion.exe" and place it on desktop.
4. "zConnexion" subpalette will appear in "Tools" after next zBrush start.
    CTRL+ALT CLICK - assign "F12" key as "Tools:zConnexion:Execute" button`s keyboard shortcut.
5. Start "zConnexion.exe".

IMPORTANT NOTES / ISSUES:
1.  While "zConnexion.exe" is running ALL data from spacemouse is routed to it, no matter what window is now in focus.
    So when you switch to other than zBrush app, in order to have spacemouse support there, you need to close "zConnexion.exe".
2.  Performance depends heavily on CPU speed. Navigations become laggy on high-poly models. 
    This is due to the fact that when updating the model position via zScript command zBrush does not perform adaptive viewport degradation.
    Try increasing sensivity to somewhat mitigate that via:
    "Tool:zConnexion:Pan sens." "Tool:zConnexion:Zoom sens." "Tool:zConnexion:Rot. sens." or 3DConnexion driver.
3.  Sometimes model flips (very very rare), that is most likely due to the fact that we have access only to Euler angles and
    not to more appropriate matrices or quaternions.